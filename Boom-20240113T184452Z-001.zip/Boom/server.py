import http.server
import socketserver

# Set the IP address and port
host = 'localhost' 
port = 8888

# Create a simple HTTP server
handler = http.server.SimpleHTTPRequestHandler
httpd = socketserver.TCPServer((host, port), handler)

print(f"Serving on {host}:{port}")

# Start the server
httpd.serve_forever()
